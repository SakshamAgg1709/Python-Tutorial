class Accha:
     
    def __init__(self) -> None:
         print("Constructor ban gaya")

    def accha_func(number):
          print("This is a function")
          return number


class Accha:     
    def __init__(self):
        print("Constructor ban gaya")

    def accha_func(self, number):
        print("This is a function")
        return number

